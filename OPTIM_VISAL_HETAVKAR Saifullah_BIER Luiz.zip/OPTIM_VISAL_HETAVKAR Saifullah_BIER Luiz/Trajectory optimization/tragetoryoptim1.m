function test()
%Main function
clc
clear
clear all
lb=[0 0 ];
ub=[10 10];
 A=[1,5];
 B=[9,5];
 P1=[5 7];
 x0 = [P1]; 
 C=[5,5];
 R=1;
options=optimset('Display','Iter',...
    'TolX',1e-8,...
    'Tolfun',1e-10,...
    'Maxiter',100,...
    'MaxfunEval',300);

x= fmincon(@(x) obj(x,A,B),x0,[],[],[],[],lb,ub,@(x)constr(x,A,B,C,R),options)
[g h]= constr(x,A,B,C,R)
figure(1); clf; 
hold on 
rectangle('Position',[0 0 10 10])
X0=[A; x0; B]
plot(X0(:,1), X0(:, 2), 'b-.')
text(A(1)-0.3,A(2),'A')
viscircles(C,R,'color','k')
X=[A; x; B]
plot(X(:,1), X(:, 2), 'r-')
text(B(1)+0.1,B(2),'B')

hold on
title('1 circle and 1 Intermediate Point')

end


function f=obj(x,A,B)
 
f=norm(A-x)+norm(B-x);
 
end


 function D=distance_segment_circle(A,B,C,n)
% A et B two point of the segement
% C center of the circle R the radius
% n number of discretization
for i=0:n
 M=A+(i/n)*(B-A); % M is a given point between A and B
 d(i+1)=norm(M-C);
end
D=min(d);
 end
function [g,h]=constr(x,A,B,C,R)
     n = 20;
    %g is unequality constraints
    g(1)=R-distance_segment_circle(A,x,C,n);
   g(2)=R-distance_segment_circle(x,B,C,n);
      h=[]; %Equality constraints
end