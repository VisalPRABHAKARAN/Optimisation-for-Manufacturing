
function test()
close all;
clear all;
clc;
xlim([0 10]);   
ylim([0 10]);
grid on;
hold on;

P1=[1,9];
P2=[9,1];


C1=[2.5,7.5];
C2=[7,3];
C3=[3,3];
C4=[7,6];
C5=[7,9];
C = [C1;C2;C3;C4;C5];
Radius=[1,1,1,0.5,0.5];
viscircles(C,Radius,'color','k');
hold on 
plot(P1(1),P1(2),'.');
text(P1(1)-0.3,P1(2),'A')
plot(P2(1),P2(2),'.');
text(P2(1)+0.1,P2(2),'B')
title('n circle and 4 Intermediate Points')
hold on;
pos=[4 0 2 4];
po= [4 6 2 4];
rectangle('position',pos);
rectangle('position',po);
x0=[1.5,6.5;3,4;6.5,9;9.5,4];
lb=[0,0;0,0;4,4;6,0];% the point in the wall restriction are restricted here
ub=[4,10;4,10;6,6;10,10];

options = optimset('Display','Iter','Tolx',1.e-6,'TolFun',1.e-6,'MaxIter',1000,'MaxFunEval',1000,'Algorithm', 'sqp');
x=fmincon(@(x)obj(x,P1,P2),x0,[],[],[],[],lb,ub,@(x)constr(x,P1,P2,C,Radius),options);
disp(x);

path = [P1;x;P2];
initial_path = [P1;x0;P2];
for i=1:size(path,1)-1
a=plot([path(i,1) path(i+1,1)],[path(i,2) path(i+1,2)],'Color',[0 0.4470 0.7410]);
plot(path(i,1),path(i,2),'x','Color',[0 0.4470 0.7410]);
b=plot([initial_path(i,1) initial_path(i+1,1)],[initial_path(i,2) initial_path(i+1,2)],'-.r');
plot(initial_path(i,1),initial_path(i,2),'xr');
legend([a,b],'optimal','non optimal')
hold on;

end
figure(1);

end

function f = obj(x,A,B)
pts = [A;x;B];
f = 0;
for i=1:length(pts)-1
f =f+norm(pts(i,:)-pts(i+1,:));
end
 
end
 function D=distance_segment_circle(A,B,C,n)
% A et B two point of the segement
% C center of the circle R the radius
% n number of discretization
for i=0:n
 M=A+(i/n)*(B-A); % M is a given point between A and B
 d(i+1)=norm(M-C);
end
D=min(d);
 end
function [g,h]=constr(x,A,B,C,R)
     n = 20;
     pts = [A;x;B];
    %g is unequality constraints
    %X=[A; x; B]
    
    for j=1:size(C,1)
    
    for i=1:length(pts)-1
   
  
       g(i+5*j)=R(j)-distance_segment_circle(pts(i,:),pts(i+1,:),C(j,:),n);
          
    end
    end

    h=[]; %Equality constraints
end