function min=optimex1()
xmin=0;
xmax=100;
ebs=0.0002;
L=xmax-xmin;

while (L>2.*ebs)
    
    L=xmax-xmin;
    
    x1=xmin+(L-ebs)/2;
    x2=xmin+(L+ebs)/2;
    
    if (fl(x1)<fl(x2))
        xmin=xmin;
        xmax=x2;
        
    else
        xmin=x1;
        xmax=xmax;
    
    end
end
min=xmin;
end