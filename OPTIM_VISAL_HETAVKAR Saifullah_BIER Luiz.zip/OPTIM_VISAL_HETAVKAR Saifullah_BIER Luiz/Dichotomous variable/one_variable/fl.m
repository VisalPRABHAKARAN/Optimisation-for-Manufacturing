function f=fl(x)
f=(1/3)*(x.^3)-2*(x.^2)+3*x+1;
end

