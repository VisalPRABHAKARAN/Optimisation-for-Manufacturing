function d=grad(X0)
d(1)=14*(X0(1)-0.5);
d(2)=6*(X0(2)-1);
d=-d/norm(d);
end
