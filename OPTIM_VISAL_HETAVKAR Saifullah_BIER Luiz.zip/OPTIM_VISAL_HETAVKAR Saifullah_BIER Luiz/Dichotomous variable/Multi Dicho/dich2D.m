clear all
close all
clc

X0= [0 1];
AlphaMin=-10;
AlphaMax=10;
eps=3;
d=grad(X0);
[xs, fs]= dich2Dfun(X0,AlphaMax,AlphaMin,d,eps)



