function contour()
figure(1);clf;
x1=-100:0.5:100;
x2=-100:0.2:100;
[X1 X2]= meshgrid(x1,x2);
Z=(X1-5).^2+(X2-3).^2;

contourf(X1,X2,Z);
 hold on
end
