function f=equation(x)
f=(3*x(1)+2*x(2)-1).^2+(x(1)-x(2)+1).^2;
end
