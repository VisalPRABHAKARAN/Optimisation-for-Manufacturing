function[xs, fs]= dich2Dfun(X,AlphaMax,AlphaMin,d,eps)
contour()
X0= [0 1];
AlphaMin=-10;
AlphaMax=10;
eps=3;
d=grad(X0);
% X0 = X;
% d=grad(X0);
% eps = e;
% AlphaMax = max;
% AlphaMin = min;
L= AlphaMax-AlphaMin;
while max(d)>eps
    X0=optim(X0,d,AlphaMin,AlphaMax,eps);
    d=grad(X0);
end

i=0;
while L>2*eps&&i<70
    Alpha1= AlphaMin+((L-eps)/2);X1=X0+Alpha1*d;
    Alpha2= AlphaMin+((L+eps)/2);X2=X0+Alpha2*d;
    figure(1);hold on;
    plot(X1(1),X1(2),'*r')
    plot(X2(1),X2(2),'*b')
    f1=equation(X1);f2=equation(X2);
    
    if f1<f2
        AlphaMax = Alpha2;
    else
        AlphaMin = Alpha1;
    end
    
    L=AlphaMax-AlphaMin;
    
end
Alphas=(AlphaMax+AlphaMin)/2;
xs=X0+Alphas*d;
fs=equation(xs);
end
