clear all;
close all;
clc;

%Main function

%x=fmincon(Name of the objective functin,...
%x0;...
%{],[],[],[],...
%lb,ub,...
%x0=[1,0] represents the variables x0(1) and x0(2)
%lb=[min of x0(1) min of x0(2)]
%ub=[max of x0(1) max of x0(2)]
pho=7800;
l=2;
x0=[0.05 0.2,0.03,0.1];
lb=[0.02 0.1,0.01,0.08];
ub=[0.3 0.3,0.3,0.3];
F=20000; 
prompt='choose among the option\n1mass minimization\n 2 deflection Minimisation\n';
y=input(prompt);
options=optimset('Display','Iter',...
    'TolX',1e-6,...
    'Tolfun',1e-6,...
    'Maxiter',300,...
    'MaxfunEval',1000);
% options=optimset('Display','iter','MaxFunEvals',100000,'MaxIter',50000,'TolFun',1e-6,'TolX',1e-10);
a=fmincon(@(x) obj(x,y),x0,[],[],[],[],lb,ub,@(x)constr(x, F,y),options)

function f=obj(x,y)
F=20000;
 L=2;
 E=2.1*10^11;
 pho=7800;
 
 if y==1
    f=(F*L^3)/(3*E*Ir(x));%minimizing the deflection
    disp("f")
    disp(f);
 end
 if y==2
     f=pho*L*Section(x);
 end
     
end
%Constraint function
function [g,h]=constr(x, F, y)
    %g is unequality constraints
   pho=7800;
   L=2;
 %  F=20000
% x=(b, h)
    sigma=2.1*10^8;
    v=x(2)/2; 
    E=2.1*10^11;
    if y==1
        g(1)=(((F*L)/Ir(x))*v)-sigma;
        g(2)=pho*L*Section(x)-300;
        h=[];
%      figure(2)
%      plot(g(1),g(2))
    end
    if y==2
        g(1)=(F*L^3)/(3*E*Ir(x))-0.01;
        g(2)=(((F*L)/Ir(x))*v)-sigma;
        h=[]; %Equality constraints
    end
       
end

function I=Ir(x)
I= (x(1)*x(2)^3-x(3)^3*(x(2)-x(4)))/12;

end

function m=Section(x)

m=x(1)*x(2)-x(3)*(x(1)-x(4));
end