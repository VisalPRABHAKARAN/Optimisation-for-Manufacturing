
close all;
clc
clear all;

L=2;
F=20000;
E=2.1e11;
rho=7800;

adstress=2.1e8;
adef=0.01;


x1=0:0.001:0.3;
x2=0:0.001:0.3;

[e, h]=meshgrid(x1,x2);
I=(e.*h.^3+e.^3.*h-e.^4)./12;
D=(F*L^3)./(3*E.*I);

M=L*rho.*(2.*h.*e-e.^2);
maxstress=(F*L./I).*h./2;



figure(1)


contour(e,h,D,[adef adef],'k-','LineWidth',2);
hold on
contour(e,h,maxstress,[adstress adstress],'r*','LineWidth',2);
hold on

contour(e,h,M,0:20:500);
hold on



legend('Deflection criteria','Stress Criteria','Mass contour lines') 
title('mass minimisation for cross section')
xlabel('e')
ylabel('h')

