clear all;
close all;
clc;

%Main function

%x=fmincon(Name of the objective functin,...
%x0;...
%{],[],[],[],...
%lb,ub,...
%x0=[1,0] represents the variables x0(1) and x0(2)
%lb=[min of x0(1) min of x0(2)]
%ub=[max of x0(1) max of x0(2)]

pho=7800;
L=2;
x0=[0.005 0.2];
lb=[0.002 0.1];
ub=[0.03 0.3];
F=20000; 
sig_a=2.1e08;
defl_a=0.01;
E=2.1e11;

%Rectangle cross section dimensions
% h=0:0.001:0.3;
% b=0:0.001:0.3;

% [B,H]= meshgrid(b,h) ; 
% f = Massminimization(B,H) ;
% figure(1);
% meshc(B,H,f) ; 
% figure(2);
% contourf(B,H,f);
% colorbar
% hold on;
% 
% %Constraint for max stress
% sigmaxconstr = 6*F*L./(sig_a*h.^2);
% plot(h,sigmaxconstr);
% ylim([0.08 0.3]);
% 
% hold on; %On same plot,
% %Constraint for max deflection
% maxdefl = 4*F*L^3./(defl_a*h.^3*E);
% plot(h,maxdefl);

options=optimset('Display','Iter',...
    'TolX',1e-6,...
    'Tolfun',1e-6,...
    'Maxiter',300,...
    'MaxfunEval',1000);
% options=optimset('Display','iter','MaxFunEvals',100000,'MaxIter',50000,'TolFun',1e-6,'TolX',1e-10);
a=fmincon(@(x) obj(x),x0,[],[],[],[],lb,ub,@(x)constr(x, F),options)

function val = Massminimization(X,Y)
F=20000;
 pho=7800;
 L=2;
  val=pho*L.*X.*Y;
end

function f=obj(x)
pho=7800;
 L=2;
  f=pho*L*Section(x);%minimizing the deflection
%  disp("f")
%  disp(f);
end

%Constraint function
function [g,h]=constr(x, F)
    %g is unequality constraints
   pho=7800;
   L=2;
%   F=20000
% x=(b, h)
 E=2.1*10^11;   
sigma=2.1*10^8;
    v=x(2)/2; 
    g(1)=(((F*L)/Ir(x))*v)-sigma;
    g(2)=(F*L^3)/(3*E*Ir(x))-0.01;
                                     
%      figure(2)
%      plot(g(1),g(2))
    h=[]; %Equality constraints
end

function I=Ir(x)
I=(x(1)*x(2)^3+x(1)^3*x(2)-x(1)^4)/12;

end

function m=Section(x)
m=2*x(1)*x(2)-x(1)^2;
end