close all
clc
clear all

L=2;
F=20000;
E=2.1e11;
rho=7800;

adstress=2.1e8;
amass=300;


x1=0:0.001:0.3;
x2=0:0.001:0.3;

[e, h]=meshgrid(x1,x2);
I=(e.*h.^3+e.^3.*h-e.^4)./12;
D=(F*L^3)./(3*E.*I);

M=L*rho.*(2*h.*e-e.^2);
S=(F*L./I).*h/2;




figure(1)


contour(e,h,S,[adstress adstress],'k:','LineWidth',4); 
hold on
contour(e,h,M,[amass amass],'r*','LineWidth',2);
hold on

hold on
contour(e,h,D,0:0.001:0.01);


hold on


xlim([0 0.3]);
ylim([0 0.3]);

legend('Stress criteria','Mass Criteria','Deflection contour lines') 
title('deflection optimisation for cross')
xlabel('e')
ylabel('h')

