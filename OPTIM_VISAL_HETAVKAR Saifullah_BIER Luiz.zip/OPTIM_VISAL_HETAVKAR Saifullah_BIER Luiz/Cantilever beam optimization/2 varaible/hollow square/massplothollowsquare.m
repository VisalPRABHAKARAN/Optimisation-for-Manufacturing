close all
clc
clear all
L=2;
F=20000;
E=2.1e11;
rho=7800;

adstress=2.1e8;
adef=0.01;
Madm=300;

x1=0.0001:0.001:0.5;
x2=x1;

[A, a]=meshgrid(x1,x2);
I=(a.^4-A.^4)./12;
M=L*rho.*(a.^2-A.^2);
D=(F*L^3)./(3*E*I);

stress=(6*F*L./(a.^4-A.^4)).*a;

figure(1)
contour(A,a,D,'LevelList',0.1:0.01:4)
hold on
contour(A,a,M,[Madm Madm],'gx','LineWidth',1.5)
hold on
contour(A,a,stress,[adstress adstress],'rx','LineWidth',1.5)

legend('DeFlection contour ','Deflection curve','Stress curve');
title('mass minismisation for hollow square')
xlabel('a')
ylabel('A')
