clc
clear all
L=2;
F=20000;
E=2.1e11;
rho=7800;

adstress=2.1e8;
adef=0.01;


x1=0.0001:0.001:0.5;
x2=x1;

[X1, X2]=meshgrid(x1,x2);
I=(X2.^4-X1.^4)./12;
M=L*rho.*(X2.^2-X1.^2);
D=(F*L^3)./(3*E*I);

stress=(6*F*L./(X2.^4-X1.^4)).*X2;

figure(1)
contour(X1,X2,M);
hold on
contour(X1,X2,D,[adef adef],'gx','LineWidth',1.5)
hold on
contour(X1,X2,stress,[adstress adstress],'rx','LineWidth',1.5)

legend('Mass contour ','Deflection curve','Stress curve');
title('Mass minismisation for hollow square')





