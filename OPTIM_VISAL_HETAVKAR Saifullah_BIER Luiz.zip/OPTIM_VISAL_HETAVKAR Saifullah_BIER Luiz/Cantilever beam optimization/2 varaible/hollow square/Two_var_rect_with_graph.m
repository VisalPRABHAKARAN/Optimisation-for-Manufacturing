clear all;
close all;
clc;

%Main function

%x=fmincon(Name of the objective functin,...
%x0;...
%{],[],[],[],...
%lb,ub,...
%x0=[1,0] represents the variables x0(1) and x0(2)
%lb=[min of x0(1) min of x0(2)]
%ub=[max of x0(1) max of x0(2)]
pho=7800;
l=2;
x0=[0.001 0.001];
lb=[0.01 0.02];
ub=[0.3 0.3];

F=20000; 

% x= [lb(1):0.01:ub(1)];
% y= [lb(2):0.01:ub(2)];
% x=0.03:0.001:0.3;
% y=0.08:0.001:0.3;
% 
% [X,Y]= meshgrid(x,y) ; 
% f = Myfunc(X,Y) ;
% figure(1);
% meshc(X,Y,f) ; 
% figure(2);
% contour(X,Y,f,'LevelList',0.001:0.001:0.2);
% colorbar
% hold on;
% x2 = 6*20000*2./(2.1*10^8*x.^2);
% plot(x,x2);
% ylim([0.08 0.3]);
% x3 = 300./(x.*7800*2);
% plot(x,x3);
% 
options=optimset('Display','Iter',...
    'TolX',1e-6,...
    'Tolfun',1e-6,...
    'Maxiter',300,...
    'MaxfunEval',1000);
% options=optimset('Display','iter','MaxFunEvals',100000,'MaxIter',50000,'TolFun',1e-6,'TolX',1e-10);
a=fmincon(@(x) obj(x),x0,[],[],[],[],lb,ub,@(x)constr(x, F),options)
function val = Myfunc(X,Y)
F=20000;
 L=2;
 E=2.1*10^11;
 I= (X.*Y.^3)/12;
 val=(F.*L^3)./(3*E.*I)
end

function f=obj(x)
F=20000;
 L=2;
 E=2.1*10^11;
 f=(F*L^3)/(3*E*Ir(x));%minimizing the deflection
 disp("f")
 disp(f);
end
%Constraint function
function [g,h]=constr(x, F)
    %g is unequality constraints
   pho=7800;
   L=2;
 %  F=20000
% x=(b, h)
    sigma=2.1*10^8;
    v=x(2)/2; 
    g(1)=(((F*L)/Ir(x))*v)-sigma;
    g(2)=pho*L*Section(x)-300;
%      figure(2)
%      plot(g(1),g(2))
    h=[]; %Equality constraints
end

function I=Ir(x)
I=(x(2)^4-x(1)^4)/12;

end

function m=Section(x)
m=(x(2)^2-x(1)^2);
end