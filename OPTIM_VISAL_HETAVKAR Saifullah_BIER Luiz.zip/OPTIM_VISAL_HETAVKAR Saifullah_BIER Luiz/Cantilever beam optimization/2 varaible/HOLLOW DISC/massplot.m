close all;
clc;
clear all;
L=2;
F=20000;
E=2.1e11;
rho=7800;

sig_a=2.1e8;
mass_a=300;
def_a = 0.01;

d=0:0.001:0.2;
D=d;

[d1, D1]=meshgrid(d,D);

I=pi*((D1.^4-d1.^4)/64);

Deflection=(F*L^3)./(3*E*I);
stressd=(D.^4-(32*F*L/(sig_a*pi))*D).^(1/4); %Find the value of d that makes sigma_x = sigma_a;
stressx = stressd(stressd==real(stressd)); 
D2(:,1:77) = D(:,125:201);

Stress=(F*L./I).*D1/2;
Mass=(rho*L*(D1.^2-d1.^2)./4)*pi;
figure;

contourf(d1,D1,Mass,0:10:300);
hold on;

contour(d1,D1,Deflection,[def_a def_a],'g-','LineWidth',5);
hold on;

plot(stressx,D2,'k-','LineWidth',5);



title('Graph of mass of hollow disc');
legend('Mass','Deflection','Stress');
xlabel('d'); 
ylabel('D'); 

caxis([0.01 0.03])

xlim([0 0.2]);
ylim([0 0.2]);





