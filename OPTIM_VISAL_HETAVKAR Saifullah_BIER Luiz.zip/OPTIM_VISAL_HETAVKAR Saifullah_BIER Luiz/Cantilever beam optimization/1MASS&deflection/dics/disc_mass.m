function test()
%Main function

%x=fmincon(Name of the objective functin,...
%x0;...
%{],[],[],[],...
%lb,ub,...

clc
clear
clear all
%x0=[1,0] represents the variables x0(1) and x0(2)
%lb=[min of x0(1) min of x0(2)]
%ub=[max of x0(1) max of x0(2)]
pho=7800;
L=2;
x0=0.6;
lb=0;
ub=10;
F=20000 ;
 E=2.1*10^11;
options=optimset('Display','Iter',...
    'TolX',1e-6,...
    'Tolfun',1e-6,...
    'Maxiter',300,...
    'MaxfunEval',1000);

d=fmincon(@(x) obj(x,pho,L),x0,[],[],[],[],lb,ub,@(x)constr(x, F,E),options)

x=0.0001:0.001:0.02;
f=obj(x,pho,L);
plot(x,f,'--')
xlabel('d')
ylabel('mass')
title('single variable d mass minimsation for disc')

end

function f=obj(x,pho,L)

    f=pho*L*mass(x);
end
%Constraint function
function [g,h]=constr(x, F,E)
    %g is unequality constraints
 
  L=2;
   sigma=2.1*10^8;
    v=x/2; 
    g(1)=(F*L * v/Isq(x))  -sigma;
    g(2)=(4*F*L^3)./(E*x.^4)-0.01;
   

    h=[]; %Equality constraints
end


function I=Isq(x)
I= (pi*x.^4)./64;
end

function m=mass(x)
m=pi*x.^2./4;
end