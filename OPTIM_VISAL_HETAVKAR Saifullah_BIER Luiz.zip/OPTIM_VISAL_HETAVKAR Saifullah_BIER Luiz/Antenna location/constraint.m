%we are trying to  make sure that your new antenna and old antenna are
%more than 10 km apart

function [g,h]=constraint(x, Antloc)

g(1)=10-norm(x-Antloc(1,:)); 
g(2)=10-norm(x-Antloc(2,:));

h=[];
end