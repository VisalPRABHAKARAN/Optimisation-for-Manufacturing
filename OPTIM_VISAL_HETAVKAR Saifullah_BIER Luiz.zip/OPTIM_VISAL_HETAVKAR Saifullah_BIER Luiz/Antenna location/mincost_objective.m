%Goal: Keep the new antenna closest to the best customers i.e. most number
%of consumption hours (hrs)
%If this is the case, distance to best customer will be smallest
%Let d(i) = distance to customer i
%Let hrs(i) = consumption hrs of customer i
%For biggest hrs(i), d(i) should be smallest
%Therefore, sum (i=1:4) hrs(i)*d(i) should be smallest

function f=mincost_objective(x,custloc)
    
f=0;
for i=1:length(custloc)
    cost=custloc(i,3)*norm(custloc(i,1:2)-x);
    f=f+cost;
end

end