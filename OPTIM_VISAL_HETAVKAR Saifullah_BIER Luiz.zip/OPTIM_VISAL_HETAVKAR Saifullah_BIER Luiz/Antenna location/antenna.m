close all
clc 
clear

%Customer locations and their consumption hours
custloc=[5,10,200;
    10,5,150;
    0,12,200;
    12,0,300];

%Antenna location
Antloc=[-5,10;
    5,0];

%Initial guess for new antenna location
x0=[4,6];
lb=[-10,-10];
ub=[15,15];

options=optimset('Display','iter','Tolx',1.e-10,'Tolfun',1.e-10,...
    'MaxIter',200, 'MaxfunEvals',2000);

obj=@(x)mincost_objective(x,custloc);
cons=@(x)constraint(x, Antloc);

x=fmincon(obj,x0,[],[],[],[],lb,ub,cons,options);

display(x);

%to plot the contour
x1=linspace(lb(1),ub(1),20);
x2=linspace(lb(2),ub(2),20);
[X1,X2]=meshgrid(x1,x2);

mincost = zeros(length(x1),length(x2));
%Plot function 
for i=1:length(x1)
    for j=1:length(x2)
        mincost(i,j)=mincost_objective([X1(i,j),X2(i,j)],custloc);
    end
end

figure(1); contourf(X1,X2,mincost); hold on; plot(x(1),x(2),'+');
title('Contour Plot of cost function f');
figure(2);
for i=1:size(custloc,1)
    plot(custloc(i,1),custloc(i,2),'*');
    hold on;
end
hold on;
for i=1:size(Antloc,1)
    plot(Antloc(i,1),Antloc(i,2),'bo')
    hold on;
    %Viscircles(Circlecenter,radius)
    viscircles(Antloc(i,:),10,'LineStyle',':','Color','b')
    hold on;
end
plot(x(1),x(2),'+');
title('Plot of Optimal New Antenna Location');
%Also shows Old Antenna locations (o) and customer locations (*)

figure(3); surf(X1,X2,mincost); hold on; plot3(x(1),x(2),mincost_objective(x,custloc),'+');
title('Surface plot of Antenna Locations')
grid on