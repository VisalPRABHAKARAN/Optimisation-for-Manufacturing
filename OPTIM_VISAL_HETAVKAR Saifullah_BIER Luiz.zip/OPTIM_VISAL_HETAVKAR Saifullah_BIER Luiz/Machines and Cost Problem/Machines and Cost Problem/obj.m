%Objective function
function f=obj(x)
    f=50*x(1)+100*x(2);
    f=-f; %that minus is used to find the max of f.
end