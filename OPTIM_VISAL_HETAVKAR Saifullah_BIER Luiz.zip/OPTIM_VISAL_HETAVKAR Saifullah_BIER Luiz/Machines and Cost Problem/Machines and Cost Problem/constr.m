%Constraint function
function [g,h]=constr(x)
    %g is unequality constraints
    g(1)=10*x(1)+5*x(2)-2500;
    g(2)=4*x(1)+10*x(2)-2000;
    g(3)=x(1)+1.5*x(2)-450;
    h=[]; %Equality constraints
end